package org.iflytek.system.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.iflytek.common.exception.ServiceException;
import org.iflytek.common.utils.StringUtils;
import org.iflytek.system.domain.Competition;
import org.iflytek.system.domain.CompetitionParticipation;
import org.iflytek.system.domain.CompetitionRegister;
import org.iflytek.system.domain.TeacherTeam;
import org.iflytek.system.domain.TeacherTeamRel;
import org.iflytek.common.core.domain.entity.SysUser;
import org.iflytek.common.utils.file.FileUtils;
import org.iflytek.system.domain.CompetitionWork;
import org.iflytek.system.mapper.CompetitionWorkMapper;
import org.iflytek.system.mapper.CompetitionMapper;
import org.iflytek.system.mapper.CompetitionParticipationMapper;
import org.iflytek.system.mapper.CompetitionRegisterMapper;
import org.iflytek.system.mapper.CompetitionReviewAssignmentMapper;
import org.iflytek.system.mapper.SysUserMapper;
import org.iflytek.system.mapper.TeacherTeamMapper;
import org.iflytek.system.mapper.TeacherTeamRelMapper;
import org.iflytek.system.service.ICompetitionStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Student-side competition registration service implementation.
 */
@Service
public class CompetitionStudentServiceImpl implements ICompetitionStudentService
{
    @Autowired
    private CompetitionWorkMapper competitionWorkMapper;

    @Autowired
    private CompetitionMapper competitionMapper;

    @Autowired
    private CompetitionRegisterMapper competitionRegisterMapper;

    @Autowired
    private CompetitionParticipationMapper competitionParticipationMapper;

    @Autowired
    private CompetitionReviewAssignmentMapper competitionReviewAssignmentMapper;

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private TeacherTeamMapper teacherTeamMapper;

    @Autowired
    private TeacherTeamRelMapper teacherTeamRelMapper;

    @Autowired
    private org.iflytek.common.utils.file.MinioUtils minioUtils;

    @Override
    public List<Competition> selectAllCompetitions()
    {
        return competitionMapper.selectCompetitionList();
    }

    @Override
    public List<Competition> selectCompetitionsByPage(Integer pageNum, Integer pageSize)
    {
        int offset = (pageNum - 1) * pageSize;
        return competitionMapper.selectCompetitionListByPage(offset, pageSize);
    }

    @Override
    public List<Competition> selectCompetitionsByPageAndFilters(Integer pageNum, Integer pageSize, Map<String, String> filters)
    {
        int offset = (pageNum - 1) * pageSize;
        return competitionMapper.selectCompetitionListByPageAndFilters(offset, pageSize, filters);
    }

    @Override
    public List<String> selectCompetitionTypes()
    {
        return competitionMapper.selectDistinctCompetitionTypes();
    }

    @Override
    public List<Map<String, Object>> getCompetitionTeams(Long competitionId)
    {
        List<CompetitionRegister> registers = competitionRegisterMapper.selectByCompetitionId(competitionId);
        Map<Long, Map<String, Object>> uniqueTeams = new HashMap<>();
        for (CompetitionRegister r : registers) {
             if (r.getTeamId() != null && !uniqueTeams.containsKey(r.getTeamId())) {
                 Map<String, Object> map = new HashMap<>();
                 map.put("teamId", r.getTeamId());
                 map.put("teamName", r.getTeamName());
                 map.put("teamMembers", r.getTeamMembers());
                 map.put("competitionId", r.getCompetitionId());
                 map.put("createTime", r.getRegisterTime());
                 uniqueTeams.put(r.getTeamId(), map);
             }
        }
        return new ArrayList<>(uniqueTeams.values());
    }

    @Override
    public Competition getCompetitionById(Long competitionId)
    {
        return competitionMapper.selectCompetitionById(competitionId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CompetitionRegister registerCompetition(Long competitionId, Long teamId, String teamName, String teamMembers,
            String workName, String workDescription, List<Map<String, Object>> teacherList, Long userId)
    {
        Competition competition = competitionMapper.selectCompetitionById(competitionId);
        if (competition == null)
        {
            throw new ServiceException("Competition not found");
        }
        Date now = new Date();
        if (competition.getRegisterStartTime() != null && competition.getRegisterStartTime().after(now))
        {
            throw new ServiceException("Registration has not started yet");
        }
        if (competition.getRegisterEndTime() != null && competition.getRegisterEndTime().before(now))
        {
            throw new ServiceException("Registration period has ended");
        }
        String finalTeamName;
        String finalTeamMembers = teamMembers;
        String finalWorkName = trimToNull(workName);
        String finalWorkDescription = trimToNull(workDescription);
        String finalTeacherName = joinTeacherNames(teacherList);

        if (teamId != null)
        {
            // Join an existing team.
            List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
            if (teamRegs == null || teamRegs.isEmpty())
            {
                throw new ServiceException("Team not found");
            }
            CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, null);
            if (!teamInfo.getCompetitionId().equals(competitionId))
            {
                throw new ServiceException("The team does not belong to this competition");
            }
            CompetitionRegister operatorRegister = competitionRegisterMapper.selectByCompetitionAndUser(competitionId, userId);
            if (operatorRegister == null || operatorRegister.getTeamId() == null || !operatorRegister.getTeamId().equals(teamId))
            {
                throw new ServiceException("只有队长才能操作");
            }
            ensureTeamEditable(operatorRegister, userId, true);
            finalTeamName = StringUtils.isEmpty(teamName) ? teamInfo.getTeamName() : teamName;
            if (finalWorkName == null)
            {
                finalWorkName = trimToNull(teamInfo.getWorkName());
            }
            if (finalWorkDescription == null)
            {
                finalWorkDescription = trimToNull(teamInfo.getWorkDescription());
            }
            if (finalTeacherName == null)
            {
                finalTeacherName = trimToNull(teamInfo.getTeacherName());
            }

            // Update team members for an existing team.
            if (!StringUtils.isEmpty(teamMembers))
            {
                finalTeamMembers = teamMembers;
                competitionRegisterMapper.updateTeamMembersByTeamId(teamId, teamMembers);
            }
            else
            {
                finalTeamMembers = teamInfo.getTeamMembers();
            }
        }
        else
        {
            // Create a new team.
            if (StringUtils.isEmpty(teamName))
            {
                throw new ServiceException("Team name cannot be empty");
            }
            if (teacherList == null || teacherList.isEmpty())
            {
                throw new ServiceException("请填写指导老师信息");
            }
            // Normalize member payload.
            String normalizedMembers = teamMembers;
            try
            {
                ObjectMapper mapper = new ObjectMapper();
                List<Map<String, Object>> members = new ArrayList<>();
                if (!StringUtils.isEmpty(teamMembers)) {
                    members = mapper.readValue(teamMembers, new TypeReference<List<Map<String, Object>>>() {});
                }
                SysUser creator = sysUserMapper.selectUserById(userId);
                String myNo = null;
                if (creator != null) {
                    myNo = creator.getStudentNo() != null ? creator.getStudentNo() : creator.getUserName();
                }
                boolean hasCreator = false;
                List<Map<String, Object>> out = new ArrayList<>();
                for (Map<String, Object> m : members) {
                    String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                    if (myNo != null && myNo.equals(mNo)) {
                        hasCreator = true;
                        m.put("status", "approved");
                        m.put("role", "leader");
                        m.remove("type");
                    } else {
                        m.put("status", "pending");
                        m.put("type", "invite");
                        if (creator != null) {
                            String inviterName = null;
                            String candidate = creator.getStudentName();
                            if (candidate == null || candidate.isEmpty()) {
                                candidate = creator.getNickName();
                            }
                            if ((candidate == null || candidate.isEmpty()) && creator.getUserName() != null && !creator.getUserName().isEmpty()) {
                                candidate = creator.getUserName();
                            }
                            inviterName = candidate;
                            m.put("inviterId", userId);
                            m.put("inviterName", inviterName);
                        }
                    }
                    out.add(m);
                }
                if (!hasCreator && myNo != null) {
                    Map<String, Object> me = new HashMap<>();
                    me.put("studentNo", myNo);
                    me.put("status", "approved");
                    me.put("role", "leader");
                    out.add(me);
                }
                normalizedMembers = mapper.writeValueAsString(out);
            }
            catch (Exception ignore)
            {
            }
            finalTeamName = teamName;
            finalTeamMembers = normalizedMembers;
        }

        ensureMembersUniqueAcrossCompetition(competitionId, teamId, finalTeamMembers);

        CompetitionRegister register = competitionRegisterMapper.selectByCompetitionAndUser(competitionId, userId);
        if (register == null)
        {
            register = new CompetitionRegister();
            register.setCompetitionId(competitionId);
            register.setTeamName(finalTeamName);
            register.setUserId(userId);
            register.setRegisterTime(now);
            register.setTeamMembers(finalTeamMembers);
            register.setWorkName(finalWorkName);
            register.setWorkDescription(finalWorkDescription);
            register.setTeacherName(finalTeacherName);

            if (teamId != null) {
                register.setTeamId(teamId);
                try {
                    competitionRegisterMapper.insertCompetitionRegister(register);
                } catch (Exception e) {
                    throw new ServiceException("You have already registered for this competition");
                }
            } else {
                // Insert first so we can derive the new team ID.
                try {
                    competitionRegisterMapper.insertCompetitionRegister(register);
                } catch (Exception e) {
                    throw new ServiceException("You have already registered for this competition");
                }
                // Use registerId as teamId.
                Long newTeamId = register.getRegisterId();
                register.setTeamId(newTeamId);
                competitionRegisterMapper.updateCompetitionRegister(register);
                teamId = newTeamId;
            }

            CompetitionParticipation participation = new CompetitionParticipation();
            participation.setParticipationId(register.getRegisterId());
            participation.setParticipationStatus("\u672a\u63d0\u4ea4");
            competitionParticipationMapper.insertCompetitionParticipation(participation);
        }
        else
        {
            // Update an existing registration.
            if (teamId == null) {
                 // Fallback: reuse registerId as teamId if the record already exists.
                 teamId = register.getRegisterId();
            }
            register.setTeamId(teamId);
            register.setTeamName(finalTeamName);
            register.setTeamMembers(finalTeamMembers);
            register.setWorkName(finalWorkName == null ? register.getWorkName() : finalWorkName);
            register.setWorkDescription(finalWorkDescription == null ? register.getWorkDescription() : finalWorkDescription);
            register.setTeacherName(finalTeacherName == null ? register.getTeacherName() : finalTeacherName);
            competitionRegisterMapper.updateCompetitionRegister(register);

            CompetitionParticipation participation = competitionParticipationMapper.selectById(register.getRegisterId());
            if (participation == null)
            {
                participation = new CompetitionParticipation();
                participation.setParticipationId(register.getRegisterId());
                participation.setParticipationStatus("\u672a\u63d0\u4ea4");
                competitionParticipationMapper.insertCompetitionParticipation(participation);
            }
        }

        if (teamId != null && !StringUtils.isEmpty(finalTeamName))
        {
            competitionRegisterMapper.updateTeamNameByTeamId(teamId, finalTeamName);
            competitionRegisterMapper.updateTeamProfileByTeamId(teamId, register.getWorkName(), register.getWorkDescription(),
                    register.getTeacherName());
        }
        syncTeamMembersRegistration(competitionId, teamId, finalTeamName, finalTeamMembers, now);
        if (teacherList != null)
        {
            replaceTeacherTeams(teamId, teacherList);
        }

        return register;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CompetitionRegister saveTeamName(Long competitionId, Long teamId, String teamName, Long userId)
    {
        Competition competition = competitionMapper.selectCompetitionById(competitionId);
        if (competition == null)
        {
            throw new ServiceException("Competition not found");
        }
        if (StringUtils.isEmpty(teamName))
        {
            throw new ServiceException("Team name cannot be empty");
        }

        Date now = new Date();
        CompetitionRegister register = competitionRegisterMapper.selectByCompetitionAndUser(competitionId, userId);
        if (register != null)
        {
            ensureTeamEditable(register, userId, true);
        }
        String teamMembers = register == null ? null : register.getTeamMembers();
        if (StringUtils.isEmpty(teamMembers))
        {
            teamMembers = buildCreatorMemberJson(userId);
        }

        if (register == null)
        {
            register = new CompetitionRegister();
            register.setCompetitionId(competitionId);
            register.setUserId(userId);
            register.setTeamName(teamName);
            register.setTeamMembers(teamMembers);
            register.setRegisterTime(now);
            competitionRegisterMapper.insertCompetitionRegister(register);

            Long newTeamId = register.getRegisterId();
            register.setTeamId(newTeamId);
            competitionRegisterMapper.updateCompetitionRegister(register);

        }
        else
        {
            if (teamId == null)
            {
                teamId = register.getTeamId() == null ? register.getRegisterId() : register.getTeamId();
            }
            register.setTeamId(teamId);
            register.setTeamName(teamName);
            register.setTeamMembers(teamMembers);
            competitionRegisterMapper.updateCompetitionRegister(register);
        }

        Long finalTeamId = register.getTeamId() == null ? register.getRegisterId() : register.getTeamId();
        register.setTeamId(finalTeamId);
        competitionRegisterMapper.updateTeamNameByTeamId(finalTeamId, teamName);
        return register;
    }

    private String buildCreatorMemberJson(Long userId)
    {
        List<Map<String, Object>> members = new ArrayList<>();
        SysUser creator = sysUserMapper.selectUserById(userId);
        Map<String, Object> me = new HashMap<>();
        if (creator != null)
        {
            me.put("userId", creator.getUserId());
            me.put("name", firstNonEmptyValue(creator.getStudentName(), creator.getNickName(), creator.getUserName()));
            me.put("studentNo", StringUtils.isEmpty(creator.getStudentNo()) ? creator.getUserName() : creator.getStudentNo());
            me.put("college", creator.getCollegeName());
            me.put("major", creator.getMajorName());
            me.put("phone", creator.getPhonenumber());
            me.put("email", creator.getEmail());
        }
        me.put("status", "approved");
        me.put("role", "leader");
        members.add(me);
        try
        {
            return new ObjectMapper().writeValueAsString(members);
        }
        catch (Exception e)
        {
            return "[]";
        }
    }

    private String firstNonEmptyValue(String... values)
    {
        if (values == null)
        {
            return "";
        }
        for (String value : values)
        {
            if (!StringUtils.isEmpty(value))
            {
                return value;
            }
        }
        return "";
    }

    private void syncTeamMembersRegistration(Long competitionId, Long teamId, String teamName, String teamMembers, Date now)
    {
        if (StringUtils.isEmpty(teamMembers))
        {
            return;
        }
        CompetitionRegister teamProfile = teamId == null ? null
                : competitionRegisterMapper.selectByCompetitionAndTeam(competitionId, teamId);
        List<Map<String, Object>> members;
        try
        {
            ObjectMapper mapper = new ObjectMapper();
            members = mapper.readValue(teamMembers, new TypeReference<List<Map<String, Object>>>() {});
        }
        catch (Exception e)
        {
            return;
        }
        if (members == null || members.isEmpty())
        {
            return;
        }
        for (Map<String, Object> m : members)
        {
            String status = m.get("status") == null ? "" : String.valueOf(m.get("status")).toLowerCase();
            if (!"approved".equals(status))
            {
                continue;
            }
            Object noObj = m.get("studentNo");
            String studentNo = noObj == null ? null : String.valueOf(noObj);
            if (StringUtils.isEmpty(studentNo))
            {
                continue;
            }
            SysUser user = sysUserMapper.selectUserByStudentNo(studentNo);
            if (user == null)
            {
                user = sysUserMapper.selectUserByUserName(studentNo);
            }
            if (user == null || user.getUserId() == null)
            {
                continue;
            }
            if (competitionRegisterMapper.selectByCompetitionAndUser(competitionId, user.getUserId()) != null)
            {
                // Keep teamMembers synchronized for existing approved members.
                CompetitionRegister existing = competitionRegisterMapper.selectByCompetitionAndUser(competitionId, user.getUserId());
                if (existing.getTeamId() != null && existing.getTeamId().equals(teamId)) {
                    existing.setTeamMembers(teamMembers);
                    existing.setTeamName(teamName);
                    if (teamProfile != null)
                    {
                        existing.setWorkName(teamProfile.getWorkName());
                        existing.setWorkDescription(teamProfile.getWorkDescription());
                        existing.setTeacherName(teamProfile.getTeacherName());
                    }
                    competitionRegisterMapper.updateCompetitionRegister(existing);
                }
                continue;
            }
            CompetitionRegister r = new CompetitionRegister();
            r.setCompetitionId(competitionId);
            r.setTeamId(teamId);
            r.setTeamName(teamName);
            r.setUserId(user.getUserId());
            r.setRegisterTime(now);
            r.setTeamMembers(teamMembers);
            if (teamProfile != null)
            {
                r.setWorkName(teamProfile.getWorkName());
                r.setWorkDescription(teamProfile.getWorkDescription());
                r.setTeacherName(teamProfile.getTeacherName());
            }
            try
            {
                competitionRegisterMapper.insertCompetitionRegister(r);
            }
            catch (Exception ignored)
            {
                continue;
            }
            CompetitionParticipation p = new CompetitionParticipation();
            p.setParticipationId(r.getRegisterId());
            p.setParticipationStatus("\u672a\u63d0\u4ea4");
            competitionParticipationMapper.insertCompetitionParticipation(p);
        }
    }

    private CompetitionRegister resolveDisplayRegister(CompetitionRegister ownRegister)
    {
        if (ownRegister == null)
        {
            return null;
        }
        if (ownRegister.getTeamId() == null)
        {
            return ownRegister;
        }
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(ownRegister.getTeamId());
        if (teamRegs == null || teamRegs.isEmpty())
        {
            return ownRegister;
        }

        CompetitionRegister leaderRegister = null;
        CompetitionRegister fallbackRegister = null;
        for (CompetitionRegister candidate : teamRegs)
        {
            if (candidate == null)
            {
                continue;
            }
            if (ownRegister.getCompetitionId() != null && candidate.getCompetitionId() != null
                    && !ownRegister.getCompetitionId().equals(candidate.getCompetitionId()))
            {
                continue;
            }
            if (fallbackRegister == null || isEarlierRegister(candidate, fallbackRegister))
            {
                fallbackRegister = candidate;
            }
            if (isRegisterOwnedByApprovedLeader(candidate)
                    && (leaderRegister == null || isEarlierRegister(candidate, leaderRegister)))
            {
                leaderRegister = candidate;
            }
        }
        if (leaderRegister != null)
        {
            return leaderRegister;
        }
        return fallbackRegister != null ? fallbackRegister : ownRegister;
    }

    private boolean isEarlierRegister(CompetitionRegister candidate, CompetitionRegister baseline)
    {
        if (candidate == null)
        {
            return false;
        }
        if (baseline == null)
        {
            return true;
        }
        if (candidate.getRegisterId() != null && baseline.getRegisterId() != null)
        {
            return candidate.getRegisterId() < baseline.getRegisterId();
        }
        if (candidate.getRegisterTime() != null && baseline.getRegisterTime() != null)
        {
            return candidate.getRegisterTime().before(baseline.getRegisterTime());
        }
        return false;
    }

    private boolean isRegisterOwnedByApprovedLeader(CompetitionRegister register)
    {
        return isUserLeaderForRegister(register, register == null ? null : register.getUserId());
    }

    private boolean isActiveMemberStatus(String status)
    {
        String normalized = status == null ? "" : status.trim().toLowerCase();
        return "".equals(normalized) || "approved".equals(normalized) || "pending".equals(normalized);
    }

    private boolean isUserLeaderForRegister(CompetitionRegister register, Long userId)
    {
        if (register == null || userId == null)
        {
            return false;
        }
        if (register.getTeamId() == null || StringUtils.isEmpty(register.getTeamMembers()))
        {
            return userId.equals(register.getUserId());
        }

        SysUser user = sysUserMapper.selectUserById(userId);
        String myNo = null;
        if (user != null)
        {
            myNo = user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();
        }
        try
        {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> members = mapper.readValue(register.getTeamMembers(),
                    new TypeReference<List<Map<String, Object>>>() {});
            if (members != null)
            {
                for (Map<String, Object> member : members)
                {
                    String mNo = String.valueOf(member.getOrDefault("studentNo", ""));
                    String status = String.valueOf(member.getOrDefault("status", "")).toLowerCase();
                    String role = String.valueOf(member.getOrDefault("role", "")).toLowerCase();
                    if (myNo != null && myNo.equals(mNo) && isActiveMemberStatus(status) && "leader".equals(role))
                    {
                        return true;
                    }
                }
                for (Map<String, Object> member : members)
                {
                    Object inviterIdObj = member.get("inviterId");
                    Long inviterId = null;
                    try
                    {
                        if (inviterIdObj != null)
                        {
                            inviterId = Long.valueOf(String.valueOf(inviterIdObj));
                        }
                    }
                    catch (Exception ignore)
                    {
                        inviterId = null;
                    }
                    if (inviterId != null && inviterId.equals(userId))
                    {
                        return true;
                    }
                }
            }
        }
        catch (Exception ignore)
        {
        }
        return false;
    }

    private boolean isReviewLockedStatus(String reviewStatusCode)
    {
        String code = reviewStatusCode == null ? "" : reviewStatusCode.trim().toLowerCase();
        return "in_review".equals(code) || "reviewed".equals(code);
    }

    private String getStudentNoByUserId(Long userId)
    {
        if (userId == null)
        {
            return null;
        }
        SysUser user = sysUserMapper.selectUserById(userId);
        if (user == null)
        {
            return null;
        }
        return user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();
    }

    private Map<String, Object> findTeamMember(List<Map<String, Object>> members, String studentNo)
    {
        if (members == null || StringUtils.isEmpty(studentNo))
        {
            return null;
        }
        String normalizedStudentNo = studentNo.trim();
        for (Map<String, Object> member : members)
        {
            if (member == null)
            {
                continue;
            }
            String memberNo = firstNonEmptyValue(
                    String.valueOf(member.getOrDefault("studentNo", "")),
                    String.valueOf(member.getOrDefault("memberStudentNo", "")),
                    String.valueOf(member.getOrDefault("applicantStudentNo", "")),
                    String.valueOf(member.getOrDefault("inviterStudentNo", "")));
            if (normalizedStudentNo.equals(StringUtils.isEmpty(memberNo) ? "" : memberNo.trim()))
            {
                return member;
            }
        }
        return null;
    }

    private CompetitionRegister resolveTeamRegister(List<CompetitionRegister> teamRegs, String studentNo)
    {
        if (teamRegs == null || teamRegs.isEmpty())
        {
            return null;
        }
        CompetitionRegister fallback = null;
        for (CompetitionRegister candidate : teamRegs)
        {
            if (candidate == null)
            {
                continue;
            }
            if (fallback == null)
            {
                fallback = candidate;
            }
            String membersJson = candidate.getTeamMembers();
            if (StringUtils.isEmpty(membersJson))
            {
                continue;
            }
            if (StringUtils.isEmpty(studentNo))
            {
                return candidate;
            }
            try
            {
                ObjectMapper mapper = new ObjectMapper();
                List<Map<String, Object>> members = mapper.readValue(membersJson,
                        new TypeReference<List<Map<String, Object>>>() {});
                if (findTeamMember(members, studentNo) != null)
                {
                    return candidate;
                }
            }
            catch (Exception ignore)
            {
            }
        }
        return fallback;
    }

    private void ensureTeamEditable(CompetitionRegister register, Long userId, boolean requireLeader)
    {
        if (register == null)
        {
            throw new ServiceException("队伍不存在");
        }
        if (requireLeader && !isUserLeaderForRegister(register, userId))
        {
            throw new ServiceException("只有队长才能操作");
        }
        CompetitionRegister displayRegister = resolveDisplayRegister(register);
        Long displayRegisterId = displayRegister == null ? null : displayRegister.getRegisterId();
        Map<String, String> reviewStatus = resolveStudentReviewStatus(displayRegisterId);
        if (isReviewLockedStatus(reviewStatus.get("code")))
        {
            throw new ServiceException("队伍已进入评审中或已评审，不能再修改报名信息");
        }
    }

    private CompetitionRegister findActiveCompetitionTeamForStudent(Long competitionId, String studentNo, Long excludedTeamId)
    {
        if (competitionId == null || StringUtils.isEmpty(studentNo))
        {
            return null;
        }
        List<CompetitionRegister> registers = competitionRegisterMapper.selectByCompetitionId(competitionId);
        if (registers == null || registers.isEmpty())
        {
            return null;
        }
        Set<Long> visitedTeamIds = new LinkedHashSet<>();
        ObjectMapper mapper = new ObjectMapper();
        for (CompetitionRegister register : registers)
        {
            if (register == null || register.getTeamId() == null)
            {
                continue;
            }
            if (excludedTeamId != null && excludedTeamId.equals(register.getTeamId()))
            {
                continue;
            }
            if (!visitedTeamIds.add(register.getTeamId()))
            {
                continue;
            }
            String membersJson = register.getTeamMembers();
            if (StringUtils.isEmpty(membersJson))
            {
                continue;
            }
            try
            {
                List<Map<String, Object>> members = mapper.readValue(membersJson,
                        new TypeReference<List<Map<String, Object>>>() {});
                if (members == null)
                {
                    continue;
                }
                for (Map<String, Object> member : members)
                {
                    String memberNo = String.valueOf(member.getOrDefault("studentNo", ""));
                    String status = String.valueOf(member.getOrDefault("status", ""));
                    if (studentNo.equals(memberNo) && isActiveMemberStatus(status))
                    {
                        return register;
                    }
                }
            }
            catch (Exception ignore)
            {
            }
        }
        return null;
    }

    private void ensureStudentHasSingleTeamSlot(Long competitionId, String studentNo, Long excludedTeamId)
    {
        CompetitionRegister existing = findActiveCompetitionTeamForStudent(competitionId, studentNo, excludedTeamId);
        if (existing != null)
        {
            throw new ServiceException("同一赛事中一个学生只能参加一个队伍");
        }
    }

    private void ensureMembersUniqueAcrossCompetition(Long competitionId, Long teamId, String teamMembers)
    {
        if (competitionId == null || StringUtils.isEmpty(teamMembers))
        {
            return;
        }
        try
        {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> members = mapper.readValue(teamMembers, new TypeReference<List<Map<String, Object>>>() {});
            if (members == null)
            {
                return;
            }
            for (Map<String, Object> member : members)
            {
                if (member == null)
                {
                    continue;
                }
                String studentNo = String.valueOf(member.getOrDefault("studentNo", ""));
                String status = String.valueOf(member.getOrDefault("status", ""));
                if (StringUtils.isEmpty(studentNo) || !isActiveMemberStatus(status))
                {
                    continue;
                }
                ensureStudentHasSingleTeamSlot(competitionId, studentNo, teamId);
            }
        }
        catch (ServiceException e)
        {
            throw e;
        }
        catch (Exception ignore)
        {
        }
    }

    @Override
    public Map<String, Object> getUserCompetitionStatus(Long competitionId, Long userId)
    {
        Map<String, Object> result = new HashMap<>();
        CompetitionRegister register = competitionRegisterMapper.selectByCompetitionAndUser(competitionId, userId);
        if (register == null)
        {
            result.put("registered", false);
            result.put("hasRecord", false);
            result.put("draft", false);
            result.put("complete", false);
            result.put("materialSubmitted", false);
            result.put("submitTime", null);
            result.put("missingFields", new ArrayList<>());
            result.put("teacherList", new ArrayList<>());
            result.put("workName", "");
            result.put("workDescription", "");
            result.put("reviewStatusCode", "");
            result.put("reviewStatusText", "");
            result.put("teamMembers", "[]");
            result.put("isLeader", false);
            result.put("canCancel", false);
            result.put("displayRegisterId", null);
            return result;
        }

        CompetitionRegister displayRegister = resolveDisplayRegister(register);
        if (displayRegister == null)
        {
            displayRegister = register;
        }

        List<Map<String, Object>> teacherResponse = buildTeacherResponse(displayRegister.getTeamId());
        CompetitionParticipation participation = competitionParticipationMapper.selectById(displayRegister.getRegisterId());
        boolean hasSubmittedMaterials = participation != null
                && hasText(participation.getPptPath())
                && hasText(getDocumentPath(participation.getPdfPath()));
        boolean legacySubmittedRecord = hasSubmittedMaterials
                && !hasText(displayRegister.getWorkName())
                && !hasText(displayRegister.getWorkDescription());

        result.put("hasRecord", true);
        result.put("registerId", register.getRegisterId());
        result.put("displayRegisterId", displayRegister.getRegisterId());
        result.put("teamId", displayRegister.getTeamId());
        result.put("teamName", displayRegister.getTeamName());
        result.put("registerTime", register.getRegisterTime());
        result.put("teacherList", teacherResponse);
        result.put("workName", legacySubmittedRecord ? "无" : defaultString(displayRegister.getWorkName()));
        result.put("workDescription", legacySubmittedRecord ? "无" : defaultString(displayRegister.getWorkDescription()));
        result.put("materialSubmitted", hasSubmittedMaterials);
        result.put("submitTime", participation == null ? null : participation.getSubmitTime());
        Map<String, String> reviewStatus = resolveStudentReviewStatus(displayRegister.getRegisterId());
        result.put("reviewStatusCode", reviewStatus.get("code"));
        result.put("reviewStatusText", reviewStatus.get("text"));

        List<Map<String, Object>> visibleMembers = new ArrayList<>();
        boolean isLeader = isUserLeaderForRegister(register, userId);
        String membersJson = displayRegister.getTeamMembers();
        if (membersJson != null)
        {
            try
            {
                ObjectMapper mapper = new ObjectMapper();
                List<Map<String, Object>> members = mapper.readValue(membersJson, new TypeReference<List<Map<String, Object>>>() {});
                if (members != null)
                {
                    SysUser user = sysUserMapper.selectUserById(userId);
                    String myNo = null;
                    if (user != null)
                    {
                        myNo = user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();
                    }
                    for (Map<String, Object> m : members)
                    {
                        String status = String.valueOf(m.getOrDefault("status", "")).toLowerCase();
                        // 保留已通过、待同意以及历史无状态的成员
                        if ("approved".equals(status) || "pending".equals(status) || "".equals(status))
                        {
                            String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                            // 总是从 sys_user 表获取最新信息，保持数据同步
                            SysUser u2 = null;
                            if (mNo != null && !mNo.isEmpty())
                            {
                                u2 = sysUserMapper.selectUserByStudentNo(mNo);
                                if (u2 == null)
                                {
                                    u2 = sysUserMapper.selectUserByUserName(mNo);
                                }
                            }
                            if (u2 != null)
                            {
                                // 更新姓名
                                String nn2 = null;
                                if (u2.getStudentName() != null && !u2.getStudentName().isEmpty()) {
                                    nn2 = u2.getStudentName();
                                } else if (u2.getNickName() != null && !u2.getNickName().isEmpty()) {
                                    nn2 = u2.getNickName();
                                } else {
                                    String uname = u2.getUserName();
                                    if (uname != null && !uname.isEmpty() && (mNo == null || !uname.equals(mNo))) {
                                        nn2 = uname;
                                    }
                                }
                                if (nn2 != null) m.put("name", nn2);
                                
                                // 更新学院
                                if (u2.getCollegeName() != null) m.put("college", u2.getCollegeName());
                                
                                // 更新专业
                                if (u2.getMajorName() != null) m.put("major", u2.getMajorName());
                                
                                // 更新电话
                                if (u2.getPhonenumber() != null) m.put("phone", u2.getPhonenumber());
                                
                                // 更新邮箱
                                if (u2.getEmail() != null) m.put("email", u2.getEmail());
                            }
                            visibleMembers.add(m);
                        }
                    }
                }
                else
                {
                    visibleMembers = new ArrayList<>();
                }
            }
            catch (Exception e)
            {
                visibleMembers = new ArrayList<>();
            }
        }
        List<String> missingFields = buildRegistrationMissingFields(displayRegister, teacherResponse, visibleMembers, hasSubmittedMaterials,
                legacySubmittedRecord);
        boolean infoComplete = isRegistrationInfoComplete(displayRegister, teacherResponse, visibleMembers, legacySubmittedRecord);
        boolean complete = missingFields.isEmpty();

        if (membersJson == null)
        {
            result.put("teamMembers", null);
        }
        else
        {
            try
            {
                result.put("teamMembers", new ObjectMapper().writeValueAsString(visibleMembers));
            }
            catch (Exception e)
            {
                result.put("teamMembers", membersJson);
            }
        }
        result.put("registered", infoComplete);
        result.put("draft", !complete);
        result.put("complete", complete);
        result.put("missingFields", missingFields);
        result.put("isLeader", isLeader);
        result.put("canCancel", isLeader && !isReviewLockedStatus(reviewStatus.get("code")));
        return result;
    }

    private String stripQueryString(String url) {
        if (url == null) return null;
        int idx = url.indexOf("?");
        if (idx != -1) {
            return url.substring(0, idx);
        }
        return url;
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private String getDocumentPath(String pdfPath) {
        if (!hasText(pdfPath)) {
            return "";
        }
        String[] parts = pdfPath.split("\\|", -1);
        return parts.length > 0 ? parts[0].trim() : "";
    }

    private String trimToNull(String value)
    {
        if (value == null)
        {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String defaultString(String value)
    {
        return value == null ? "" : value;
    }

    private String joinTeacherNames(List<Map<String, Object>> teacherList)
    {
        if (teacherList == null || teacherList.isEmpty())
        {
            return null;
        }
        List<String> names = new ArrayList<>();
        for (Map<String, Object> teacher : teacherList)
        {
            if (teacher == null)
            {
                continue;
            }
            Object rawName = teacher.get("name");
            String name = trimToNull(rawName == null ? null : String.valueOf(rawName));
            if (name != null)
            {
                names.add(name);
            }
        }
        return names.isEmpty() ? null : String.join("、", names);
    }

    private List<String> buildRegistrationMissingFields(CompetitionRegister register, List<Map<String, Object>> teacherList,
            List<Map<String, Object>> members, boolean hasSubmittedMaterials, boolean legacySubmittedRecord)
    {
        List<String> missingFields = new ArrayList<>();
        if (register == null || !hasText(register.getTeamName()))
        {
            missingFields.add("队伍名称");
        }
        if (teacherList == null || teacherList.isEmpty())
        {
            missingFields.add("指导老师");
        }
        if (!hasCompleteLeader(members))
        {
            missingFields.add("队长信息");
        }
        if (!hasCompleteNonLeaderMember(members))
        {
            missingFields.add("至少一位队员");
        }
        if (!legacySubmittedRecord && !hasText(register == null ? null : register.getWorkName()))
        {
            missingFields.add("作品名称");
        }
        if (!legacySubmittedRecord && !hasText(register == null ? null : register.getWorkDescription()))
        {
            missingFields.add("作品简介");
        }
        if (!hasSubmittedMaterials)
        {
            missingFields.add("申报书资料/PPT演示资料");
        }
        return missingFields;
    }

    private boolean isRegistrationInfoComplete(CompetitionRegister register, List<Map<String, Object>> teacherList,
            List<Map<String, Object>> members, boolean legacySubmittedRecord)
    {
        return register != null
                && hasText(register.getTeamName())
                && teacherList != null
                && !teacherList.isEmpty()
                && hasCompleteLeader(members)
                && hasCompleteNonLeaderMember(members)
                && (legacySubmittedRecord || hasText(register.getWorkName()))
                && (legacySubmittedRecord || hasText(register.getWorkDescription()));
    }

    private boolean hasCompleteLeader(List<Map<String, Object>> members)
    {
        if (members == null || members.isEmpty())
        {
            return false;
        }
        Map<String, Object> leader = null;
        for (Map<String, Object> member : members)
        {
            if ("leader".equalsIgnoreCase(String.valueOf(member.getOrDefault("role", ""))))
            {
                leader = member;
                break;
            }
        }
        if (leader == null)
        {
            leader = members.get(0);
        }
        return isCompleteStudentMember(leader);
    }

    private boolean hasCompleteNonLeaderMember(List<Map<String, Object>> members)
    {
        if (members == null || members.isEmpty())
        {
            return false;
        }
        for (Map<String, Object> member : members)
        {
            if ("rejected".equalsIgnoreCase(String.valueOf(member.getOrDefault("status", ""))))
            {
                continue;
            }
            if ("leader".equalsIgnoreCase(String.valueOf(member.getOrDefault("role", ""))))
            {
                continue;
            }
            if (isCompleteStudentMember(member))
            {
                return true;
            }
        }
        return false;
    }

    private boolean isCompleteStudentMember(Map<String, Object> member)
    {
        if (member == null)
        {
            return false;
        }
        return hasText(memberText(member, "name"))
                && hasText(memberText(member, "studentNo"))
                && hasText(memberText(member, "college"))
                && hasText(memberText(member, "major"))
                && hasText(memberText(member, "phone"))
                && hasText(memberText(member, "email"));
    }

    private String memberText(Map<String, Object> member, String key)
    {
        if (member == null || key == null)
        {
            return "";
        }
        Object value = member.get(key);
        return value == null ? "" : String.valueOf(value);
    }

    private Map<String, String> resolveStudentReviewStatus(Long registerId)
    {
        Map<String, String> status = new HashMap<>();
        status.put("code", "");
        status.put("text", "");
        if (registerId == null)
        {
            return status;
        }
        CompetitionParticipation participation = competitionParticipationMapper.selectById(registerId);
        if (participation == null || participation.getSubmitTime() == null)
        {
            return status;
        }

        List<org.iflytek.system.domain.CompetitionReviewAssignment> assignments =
                competitionReviewAssignmentMapper.selectByParticipationId(registerId);
        if (assignments == null || assignments.isEmpty())
        {
            status.put("code", "pending_review");
            status.put("text", "待审核");
            return status;
        }

        boolean allReviewed = true;
        for (org.iflytek.system.domain.CompetitionReviewAssignment assignment : assignments)
        {
            if (assignment == null || !"REVIEWED".equalsIgnoreCase(String.valueOf(assignment.getAssignmentStatus())))
            {
                allReviewed = false;
                break;
            }
        }
        if (allReviewed)
        {
            status.put("code", "reviewed");
            status.put("text", "已评审");
        }
        else
        {
            status.put("code", "in_review");
            status.put("text", "评审中");
        }
        return status;
    }

    @Override
    public void submitMaterials(Long registerId, String pptPath, String pdfPath, String fileNames, String workName,
            String workDescription, Long userId)
    {
        if (!hasText(pptPath) || !hasText(getDocumentPath(pdfPath)))
        {
            throw new ServiceException("申报书资料和PPT演示资料均为必填项");
        }
        if (!hasText(workName))
        {
            throw new ServiceException("请输入作品名称");
        }
        if (!hasText(workDescription))
        {
            throw new ServiceException("请输入作品简介");
        }
        CompetitionRegister register = competitionRegisterMapper.selectById(registerId);
        if (register == null)
        {
            throw new ServiceException("报名记录不存在");
        }
        ensureTeamEditable(register, userId, true);
        CompetitionParticipation participation = competitionParticipationMapper.selectById(registerId);
        if (participation == null)
        {
            participation = new CompetitionParticipation();
            participation.setParticipationId(registerId);
            participation.setParticipationStatus("\u672a\u63d0\u4ea4");
            competitionParticipationMapper.insertCompetitionParticipation(participation);
        }

        if (pptPath != null) pptPath = stripQueryString(pptPath);
        if (pdfPath != null) {
            if (pdfPath.contains("|")) {
                String[] parts = pdfPath.split("\\|");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length; i++) {
                    if (i > 0) sb.append("|");
                    sb.append(stripQueryString(parts[i]));
                }
                pdfPath = sb.toString();
            } else {
                pdfPath = stripQueryString(pdfPath);
            }
        }
        
        participation.setPptPath(pptPath);
        participation.setPdfPath(pdfPath);
        participation.setSubmitTime(new Date());
        participation.setParticipationStatus("\u5df2\u63d0\u4ea4");

        competitionParticipationMapper.updateCompetitionParticipation(participation);
        register.setWorkName(workName.trim());
        register.setWorkDescription(workDescription.trim());
        competitionRegisterMapper.updateCompetitionRegister(register);
        if (register.getTeamId() != null)
        {
            competitionRegisterMapper.updateTeamProfileByTeamId(register.getTeamId(), register.getWorkName(),
                    register.getWorkDescription(), register.getTeacherName());
        }

        competitionWorkMapper.deleteCompetitionWorkByParticipationId(registerId);

        Map<String, String> namesMap = new HashMap<>();
        if (fileNames != null && !fileNames.isEmpty()) {
            try {
                ObjectMapper mapper = new ObjectMapper();
                namesMap = mapper.readValue(fileNames, new TypeReference<Map<String, String>>(){});
            } catch (Exception ignore) {}
        }

        if (pptPath != null && !pptPath.isEmpty()) {
            CompetitionWork work = new CompetitionWork();
            work.setParticipationId(registerId);
            String name = namesMap.get("ppt");
            if (name == null || name.isEmpty()) {
                name = FileUtils.getName(pptPath);
            }
            work.setFileName(name);
            work.setFilePath(pptPath);
            work.setFileType("ppt");
            work.setCreateTime(new Date());
            competitionWorkMapper.insertCompetitionWork(work);
        }

        if (pdfPath != null && !pdfPath.isEmpty()) {
            String[] parts = pdfPath.split("\\|");
            
            for (String path : parts) {
                if (path == null || path.isEmpty()) continue;
                CompetitionWork work = new CompetitionWork();
                work.setParticipationId(registerId);
                work.setFilePath(path);
                
                String lower = path.toLowerCase();
                String name = "";
                if (lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z")) {
                    work.setFileType("zip");
                    name = namesMap.get("other");
                } else {
                    work.setFileType("pdf"); 
                    name = namesMap.get("doc");
                }
                
                if (name == null || name.isEmpty()) {
                    name = FileUtils.getName(path);
                }
                work.setFileName(name);
                work.setCreateTime(new Date());
                competitionWorkMapper.insertCompetitionWork(work);
            }
        }
    }

    @Override
    public Map<String, Object> getUploadedMaterials(Long registerId)
    {
        CompetitionParticipation participation = competitionParticipationMapper.selectById(registerId);
        Map<String, Object> result = new HashMap<>();
        if (participation != null)
        {
            CompetitionWork query = new CompetitionWork();
            query.setParticipationId(registerId);
            List<CompetitionWork> works = competitionWorkMapper.selectCompetitionWorkList(query);
            
            String pptPath = null;
            String pdfPath = null;
            String pptName = null;
            String docName = null;
            String otherName = null;
            String docPath = null;
            String zipPath = null;
            
            if (works != null && !works.isEmpty()) {
                 for (CompetitionWork work : works) {
                     if ("ppt".equals(work.getFileType())) {
                         pptPath = work.getFilePath();
                         pptName = work.getFileName();
                     } else if ("zip".equals(work.getFileType())) {
                         zipPath = work.getFilePath();
                         otherName = work.getFileName();
                     } else {
                         docPath = work.getFilePath();
                         docName = work.getFileName();
                     }
                 }
                 
                 if (docPath != null) {
                     pdfPath = docPath;
                 }
                 if (zipPath != null) {
                     if (pdfPath != null) pdfPath += "|" + zipPath;
                     else pdfPath = "|" + zipPath;
                 }
            } else {
                pptPath = participation.getPptPath();
                pdfPath = participation.getPdfPath();
            }

            if (pptPath != null && !pptPath.isEmpty()) {
                pptPath = minioUtils.getPrivateUrl(pptPath);
            }
            if (pdfPath != null && !pdfPath.isEmpty()) {
                if (pdfPath.contains("|")) {
                    String[] parts = pdfPath.split("\\|");
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < parts.length; i++) {
                        if (i > 0) sb.append("|");
                        sb.append(minioUtils.getPrivateUrl(parts[i]));
                    }
                    pdfPath = sb.toString();
                } else {
                    if (pdfPath.startsWith("|")) {
                         String p = pdfPath.substring(1);
                         pdfPath = "|" + minioUtils.getPrivateUrl(p);
                    } else {
                         pdfPath = minioUtils.getPrivateUrl(pdfPath);
                    }
                }
            }

            result.put("pptPath", pptPath);
            result.put("pdfPath", pdfPath);
            result.put("pptName", pptName);
            String finalDocName = docName == null ? "" : docName;
            String finalOtherName = otherName == null ? "" : otherName;
            if (docName != null || otherName != null) {
                result.put("pdfNames", finalDocName + "|" + finalOtherName);
            } else {
                result.put("pdfNames", "");
            }
            
            result.put("submitTime", participation.getSubmitTime());
            result.put("participationStatus", participation.getParticipationStatus());
        }
        else
        {
            result.put("pptPath", null);
            result.put("pdfPath", null);
            result.put("pptName", null);
            result.put("pdfNames", null);
            result.put("submitTime", null);
            result.put("participationStatus", null);
        }
        return result;
    }

    @Override
    public List<Map<String, Object>> getRecentRegistrations(Long userId, Integer limit)
    {
        if (limit == null || limit <= 0)
        {
            limit = 10;
        }
        List<Map<String, Object>> raw = competitionRegisterMapper.selectRecentRegistrationsByUser(userId, limit);
        if (raw == null || raw.isEmpty())
        {
            return raw;
        }
        SysUser user = sysUserMapper.selectUserById(userId);
        String myNo = null;
        if (user != null)
        {
            myNo = user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();
        }
        List<Map<String, Object>> filtered = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        for (Map<String, Object> item : raw)
        {
            Object teamMembersObj = item.get("teamMembers");
            String teamMembers = teamMembersObj != null ? String.valueOf(teamMembersObj) : null;

            if (teamMembers == null || teamMembers.isEmpty())
            {
                filtered.add(item);
                continue;
            }
            boolean include = true;
            try
            {
                List<Map<String, Object>> members = mapper.readValue(teamMembers, new TypeReference<List<Map<String, Object>>>() {});
                if (myNo != null)
                {
                    include = false;
                    for (Map<String, Object> m : members)
                    {
                        String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                        String status = String.valueOf(m.getOrDefault("status", ""));
                        if (myNo.equals(mNo))
                        {
                            String s = status == null ? "" : status.toLowerCase();
                            if ("approved".equals(s) || "".equals(s))
                            {
                                include = true;
                            }
                            break;
                        }
                    }
                }
            }
            catch (Exception ignore)
            {
                include = true;
            }
            if (include)
            {
                Long registerId = null;
                try
                {
                    Object registerIdObj = item.get("registerId");
                    if (registerIdObj != null)
                    {
                        registerId = Long.valueOf(String.valueOf(registerIdObj));
                    }
                }
                catch (Exception ignore)
                {
                    registerId = null;
                }
                CompetitionRegister ownRegister = registerId == null ? null : competitionRegisterMapper.selectById(registerId);
                CompetitionRegister displayRegister = resolveDisplayRegister(ownRegister);
                Long displayRegisterId = displayRegister == null ? registerId : displayRegister.getRegisterId();
                Map<String, String> reviewStatus = resolveStudentReviewStatus(displayRegisterId);
                item.put("reviewStatus", reviewStatus.get("code"));
                item.put("reviewStatusCode", reviewStatus.get("code"));
                item.put("reviewStatusText", reviewStatus.get("text"));
                item.put("status", reviewStatus.get("code"));
                item.put("displayRegisterId", displayRegisterId);
                boolean isLeader = isUserLeaderForRegister(ownRegister, userId);
                item.put("isLeader", isLeader);
                item.put("canCancel", isLeader && !isReviewLockedStatus(reviewStatus.get("code")));
                if (displayRegister != null && hasText(displayRegister.getTeamName()))
                {
                    item.put("teamName", displayRegister.getTeamName());
                }
                filtered.add(item);
            }
        }
        return filtered;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean cancelRegistration(Long registerId, Long userId)
    {
        CompetitionRegister register = competitionRegisterMapper.selectById(registerId);
        if (register == null)
        {
            throw new ServiceException("Registration record not found");
        }
        if (!register.getUserId().equals(userId))
        {
            throw new ServiceException("You do not have permission to cancel this registration");
        }
        ensureTeamEditable(register, userId, true);
        if (register.getTeamId() != null && !StringUtils.isEmpty(register.getTeamMembers()))
        {
            String studentNo = null;
            SysUser user = sysUserMapper.selectUserById(userId);
            if (user != null)
            {
                studentNo = StringUtils.isEmpty(user.getStudentNo()) ? user.getUserName() : user.getStudentNo();
            }
            try
            {
                ObjectMapper mapper = new ObjectMapper();
                List<Map<String, Object>> members = mapper.readValue(register.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
                if (members != null && !members.isEmpty())
                {
                    List<Map<String, Object>> filtered = new ArrayList<>();
                    for (Map<String, Object> m : members)
                    {
                        Object noObj = m.get("studentNo");
                        String mNo = noObj == null ? null : String.valueOf(noObj);
                        if (studentNo != null && studentNo.equals(mNo))
                        {
                            continue;
                        }
                        filtered.add(m);
                    }
                    String newJson = mapper.writeValueAsString(filtered);
                    // Update all members with this new JSON
                    competitionRegisterMapper.updateTeamMembersByTeamId(register.getTeamId(), newJson);
                }
            }
            catch (Exception ignore)
            {
            }
        }

        competitionWorkMapper.deleteCompetitionWorkByParticipationId(registerId);
        competitionParticipationMapper.deleteById(registerId);
        boolean deleted = competitionRegisterMapper.deleteById(registerId) > 0;
        cleanupTeacherTeamsIfEmpty(register.getTeamId());
        return deleted;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean removeMember(Long teamId, String studentNo, Long operatorUserId)
    {
        if (teamId == null || StringUtils.isEmpty(studentNo))
        {
            throw new ServiceException("Parameters are incomplete");
        }
        // Get team info from any register
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty()) {
            throw new ServiceException("Team not found");
        }
        CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, studentNo);
        CompetitionRegister operatorRegister = competitionRegisterMapper.selectByCompetitionAndUser(teamInfo.getCompetitionId(), operatorUserId);
        if (operatorRegister == null || operatorRegister.getTeamId() == null || !operatorRegister.getTeamId().equals(teamId))
        {
            throw new ServiceException("Only the team leader can remove members");
        }
        ensureTeamEditable(operatorRegister, operatorUserId, true);
        
        boolean operatorIsLeader = false;
        String operatorNo = null;
        SysUser operator = sysUserMapper.selectUserById(operatorUserId);
        if (operator != null)
        {
            operatorNo = operator.getStudentNo() != null ? operator.getStudentNo() : operator.getUserName();
        }
        try
        {
            ObjectMapper mapper = new ObjectMapper();
            List<Map<String, Object>> members = new ArrayList<>();
            if (!StringUtils.isEmpty(teamInfo.getTeamMembers()))
            {
                members = mapper.readValue(teamInfo.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
            }
            for (Map<String, Object> m : members)
            {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                String status = String.valueOf(m.getOrDefault("status", "")).toLowerCase();
                String role = String.valueOf(m.getOrDefault("role", "")).toLowerCase();
                if (operatorNo != null && operatorNo.equals(mNo) && "approved".equals(status) && "leader".equals(role))
                {
                    operatorIsLeader = true;
                    break;
                }
            }
            if (!operatorIsLeader)
            {
                for (Map<String, Object> m : members)
                {
                    Object inviterIdObj = m.get("inviterId");
                    Long inviterId = null;
                    try { if (inviterIdObj != null) inviterId = Long.valueOf(String.valueOf(inviterIdObj)); } catch (Exception ignore) { inviterId = null; }
                    if (inviterId != null && inviterId.equals(operatorUserId))
                    {
                        operatorIsLeader = true;
                        break;
                    }
                }
            }
            if (!operatorIsLeader)
            {
                throw new ServiceException("Only the team leader can remove members");
            }
            List<Map<String, Object>> filtered = new ArrayList<>();
            boolean removedApprovedMember = false;
            for (Map<String, Object> m : members)
            {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                if (studentNo.equals(mNo))
                {
                    String status = String.valueOf(m.getOrDefault("status", "")).toLowerCase();
                    if ("approved".equals(status))
                    {
                        removedApprovedMember = true;
                    }
                    continue;
                }
                filtered.add(m);
            }
            String newJson = mapper.writeValueAsString(filtered);
            competitionRegisterMapper.updateTeamMembersByTeamId(teamId, newJson);

            if (removedApprovedMember)
            {
                SysUser removedUser = sysUserMapper.selectUserByStudentNo(studentNo);
                if (removedUser == null)
                {
                    removedUser = sysUserMapper.selectUserByUserName(studentNo);
                }
                if (removedUser != null && removedUser.getUserId() != null)
                {
                    CompetitionRegister register = competitionRegisterMapper.selectByCompetitionAndUser(teamInfo.getCompetitionId(), removedUser.getUserId());
                    if (register != null && register.getTeamId() != null && register.getTeamId().equals(teamId))
                    {
                        competitionParticipationMapper.deleteById(register.getRegisterId());
                        competitionRegisterMapper.deleteById(register.getRegisterId());
                    }
                }
            }
            cleanupTeacherTeamsIfEmpty(teamId);
            return true;
        }
        catch (ServiceException se)
        {
            throw se;
        }
        catch (Exception e)
        {
            throw new ServiceException("Failed to remove team member");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean inviteMember(Long teamId, String studentNo, Long inviterUserId)
    {
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty()) {
            throw new ServiceException("Team not found");
        }
        CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, studentNo);
        CompetitionRegister inviterRegister = competitionRegisterMapper.selectByCompetitionAndUser(teamInfo.getCompetitionId(), inviterUserId);
        if (inviterRegister == null || inviterRegister.getTeamId() == null || !inviterRegister.getTeamId().equals(teamId))
        {
            throw new ServiceException("只有队长才能操作");
        }
        ensureTeamEditable(inviterRegister, inviterUserId, true);

        SysUser inviter = sysUserMapper.selectUserById(inviterUserId);
        String inviterName = null;
        if (inviter != null) {
            String candidate = inviter.getStudentName();
            if (candidate == null || candidate.isEmpty()) {
                candidate = inviter.getNickName();
            }
            if ((candidate == null || candidate.isEmpty()) && inviter.getUserName() != null && !inviter.getUserName().isEmpty()) {
                candidate = inviter.getUserName();
            }
            inviterName = candidate;
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            List<Map<String, Object>> members = new ArrayList<>();
            if (teamInfo.getTeamMembers() != null && !teamInfo.getTeamMembers().isEmpty()) {
                members = mapper.readValue(teamInfo.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
            }
            SysUser invited = sysUserMapper.selectUserByStudentNo(studentNo);
            if (invited == null) {
                invited = sysUserMapper.selectUserByUserName(studentNo);
            }
            
            // 检查被邀请用户是否已在同一竞赛的其他队伍中报名
            ensureStudentHasSingleTeamSlot(teamInfo.getCompetitionId(), studentNo, teamId);
            
            String invitedName = null;
            String invitedMajor = null;
            String invitedPhone = null;
            String invitedEmail = null;
            if (invited != null) {
                String candidate = invited.getStudentName();
                if (candidate == null || candidate.isEmpty()) {
                    candidate = invited.getNickName();
                }
                if ((candidate == null || candidate.isEmpty()) && invited.getUserName() != null && !invited.getUserName().isEmpty()) {
                    if (!invited.getUserName().equals(studentNo)) {
                        candidate = invited.getUserName();
                    }
                }
                invitedName = (candidate != null && !candidate.isEmpty()) ? candidate : null;
                invitedMajor = invited.getMajorName();
                invitedPhone = invited.getPhonenumber();
                invitedEmail = invited.getEmail();
            }
            boolean exists = false;
            for (Map<String, Object> m : members) {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                if (studentNo.equals(mNo)) {
                    exists = true;
                    m.put("status", "pending");
                    m.put("type", "invite");
                    m.put("inviterId", inviterUserId);
                    if (inviterName != null) m.put("inviterName", inviterName);
                    if (invitedName != null) m.put("name", invitedName);
                    if (invitedMajor != null) m.put("major", invitedMajor);
                    if (invitedPhone != null && !invitedPhone.isEmpty()) m.put("phone", invitedPhone);
                    if (invitedEmail != null && !invitedEmail.isEmpty()) m.put("email", invitedEmail);
                }
            }
            if (!exists) {
                Map<String, Object> entry = new HashMap<>();
                entry.put("studentNo", studentNo);
                entry.put("status", "pending");
                entry.put("type", "invite");
                entry.put("inviterId", inviterUserId);
                if (inviterName != null) entry.put("inviterName", inviterName);
                if (invitedName != null) entry.put("name", invitedName);
                if (invitedMajor != null) entry.put("major", invitedMajor);
                if (invitedPhone != null && !invitedPhone.isEmpty()) entry.put("phone", invitedPhone);
                if (invitedEmail != null && !invitedEmail.isEmpty()) entry.put("email", invitedEmail);
                members.add(entry);
            }
            String newJson = mapper.writeValueAsString(members);
            competitionRegisterMapper.updateTeamMembersByTeamId(teamId, newJson);
            return true;
        } catch (Exception e) {
            throw new ServiceException("邀请失败: " + e.getMessage());
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean applyJoinTeam(Long teamId, Long applicantUserId)
    {
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty()) {
            throw new ServiceException("Team not found");
        }
        SysUser user = sysUserMapper.selectUserById(applicantUserId);
        if (user == null) {
            throw new ServiceException("User not found");
        }
        String studentNo = user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();
        CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, studentNo);
        ensureTeamEditable(teamInfo, applicantUserId, false);
        String applicantName = firstNonEmptyValue(user.getStudentName(), user.getNickName(), user.getUserName());
        String collegeName = firstNonEmptyValue(user.getCollegeName());
        String majorName = firstNonEmptyValue(user.getMajorName());
        String phone = firstNonEmptyValue(user.getPhonenumber());
        String email = firstNonEmptyValue(user.getEmail());
        if (StringUtils.isEmpty(applicantName) || StringUtils.isEmpty(studentNo) || StringUtils.isEmpty(collegeName)
                || StringUtils.isEmpty(majorName) || StringUtils.isEmpty(phone) || StringUtils.isEmpty(email))
        {
            throw new ServiceException("请先到个人中心完善个人信息后再申请加入队伍");
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            ensureStudentHasSingleTeamSlot(teamInfo.getCompetitionId(), studentNo, teamId);
            List<Map<String, Object>> members = new ArrayList<>();
            if (teamInfo.getTeamMembers() != null && !teamInfo.getTeamMembers().isEmpty()) {
                members = mapper.readValue(teamInfo.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
            }
            for (Map<String, Object> m : members) {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                if (studentNo.equals(mNo)) {
                    String status = String.valueOf(m.getOrDefault("status", "")).toLowerCase();
                    String type = String.valueOf(m.getOrDefault("type", "")).toLowerCase();
                    if ("approved".equals(status) || "".equals(status)) {
                        throw new ServiceException("您已在该队伍中");
                    }
                    if ("pending".equals(status)) {
                        if ("invite".equals(type)) {
                            throw new ServiceException("该队伍已向您发送邀请，请到我的消息中处理");
                        }
                        throw new ServiceException("您已提交过申请，请等待队长审批");
                    }
                    if ("rejected".equals(status) && "apply".equals(type)) {
                        throw new ServiceException("您对该队伍的申请已被驳回，暂不可重复申请");
                    }
                }
            }
            Map<String, Object> entry = new HashMap<>();
            entry.put("studentNo", studentNo);
            entry.put("status", "pending");
            entry.put("type", "apply");
            entry.put("role", "member");
            entry.put("applicantUserId", applicantUserId);
            entry.put("applicantName", applicantName);
            entry.put("name", applicantName);
            entry.put("college", collegeName);
            entry.put("major", majorName);
            entry.put("phone", phone);
            entry.put("email", email);
            entry.put("createTime", new Date().getTime());
            members.add(entry);
            String newJson = mapper.writeValueAsString(members);
            competitionRegisterMapper.updateTeamMembersByTeamId(teamId, newJson);
            return true;
        } catch (Exception e) {
            if (e instanceof ServiceException) {
                throw (ServiceException) e;
            }
            throw new ServiceException("Failed to submit application");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean approveMember(Long teamId, String studentNo, Long approverUserId)
    {
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty()) {
            throw new ServiceException("Team not found");
        }
        CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, studentNo);

        ObjectMapper mapper = new ObjectMapper();
        try {
            List<Map<String, Object>> members = new ArrayList<>();
            if (teamInfo.getTeamMembers() != null && !teamInfo.getTeamMembers().isEmpty()) {
                members = mapper.readValue(teamInfo.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
            }
            Map<String, Object> targetMember = findTeamMember(members, studentNo);
            if (targetMember == null) {
                throw new ServiceException("Pending member not found");
            }
            String targetStatus = String.valueOf(targetMember.getOrDefault("status", "")).toLowerCase();
            if (!"pending".equals(targetStatus)) {
                throw new ServiceException("Pending member not found");
            }
            String targetType = String.valueOf(targetMember.getOrDefault("type", "invite")).toLowerCase();
            if ("apply".equals(targetType)) {
                CompetitionRegister approverRegister = competitionRegisterMapper.selectByCompetitionAndUser(teamInfo.getCompetitionId(), approverUserId);
                if (approverRegister == null || approverRegister.getTeamId() == null || !approverRegister.getTeamId().equals(teamId))
                {
                    throw new ServiceException("只有队长才能操作");
                }
                ensureTeamEditable(approverRegister, approverUserId, true);
            } else {
                ensureTeamEditable(teamInfo, approverUserId, false);
                String approverStudentNo = getStudentNoByUserId(approverUserId);
                if (StringUtils.isEmpty(approverStudentNo) || !studentNo.equals(approverStudentNo))
                {
                    throw new ServiceException("只有被邀请学生才能处理该邀请");
                }
            }

            ensureStudentHasSingleTeamSlot(teamInfo.getCompetitionId(), studentNo, teamId);
            boolean updated = false;
            for (Map<String, Object> m : members) {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                if (studentNo.equals(mNo)) {
                    m.put("status", "approved");
                    SysUser u = sysUserMapper.selectUserByStudentNo(studentNo);
                    if (u == null) u = sysUserMapper.selectUserByUserName(studentNo);
                    if (u != null) {
                        Object nameObj = m.get("name");
                        String nm = nameObj == null ? null : String.valueOf(nameObj);
                        if (nm == null || nm.isEmpty()) {
                            String nn = u.getStudentName();
                            if (nn == null) nn = u.getNickName();
                            if (nn == null) nn = u.getUserName();
                            if (nn != null) m.put("name", nn);
                        }
                        Object collegeObj = m.get("college");
                        if ((collegeObj == null || String.valueOf(collegeObj).isEmpty()) && u.getCollegeName() != null) {
                            m.put("college", u.getCollegeName());
                        }
                        Object majorObj = m.get("major");
                        if ((majorObj == null || String.valueOf(majorObj).isEmpty()) && u.getMajorName() != null) {
                            m.put("major", u.getMajorName());
                        }
                        Object phoneObj = m.get("phone");
                        if ((phoneObj == null || String.valueOf(phoneObj).isEmpty()) && u.getPhonenumber() != null) {
                            m.put("phone", u.getPhonenumber());
                        }
                        Object emailObj = m.get("email");
                        if ((emailObj == null || String.valueOf(emailObj).isEmpty()) && u.getEmail() != null) {
                            m.put("email", u.getEmail());
                        }
                    }
                    updated = true;
                    break;
                }
            }
            if (!updated) {
                throw new ServiceException("Pending member not found");
            }
            String newJson = mapper.writeValueAsString(members);
            competitionRegisterMapper.updateTeamMembersByTeamId(teamId, newJson);

            // Sync
            syncTeamMembersRegistration(teamInfo.getCompetitionId(), teamInfo.getTeamId(), teamInfo.getTeamName(), newJson, new Date());
            return true;
        } catch (ServiceException se) {
            throw se;
        } catch (Exception e) {
            throw new ServiceException("Approval failed");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean rejectMember(Long teamId, String studentNo, Long approverUserId)
    {
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty()) {
            throw new ServiceException("Team not found");
        }
        CompetitionRegister teamInfo = resolveTeamRegister(teamRegs, studentNo);

        ObjectMapper mapper = new ObjectMapper();
        try {
            List<Map<String, Object>> members = new ArrayList<>();
            if (teamInfo.getTeamMembers() != null && !teamInfo.getTeamMembers().isEmpty()) {
                members = mapper.readValue(teamInfo.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
            }
            Map<String, Object> targetMember = findTeamMember(members, studentNo);
            if (targetMember == null) {
                throw new ServiceException("Pending member not found");
            }
            String targetStatus = String.valueOf(targetMember.getOrDefault("status", "")).toLowerCase();
            if (!"pending".equals(targetStatus)) {
                throw new ServiceException("Pending member not found");
            }
            String targetType = String.valueOf(targetMember.getOrDefault("type", "invite")).toLowerCase();
            if ("apply".equals(targetType)) {
                CompetitionRegister approverRegister = competitionRegisterMapper.selectByCompetitionAndUser(teamInfo.getCompetitionId(), approverUserId);
                if (approverRegister == null || approverRegister.getTeamId() == null || !approverRegister.getTeamId().equals(teamId))
                {
                    throw new ServiceException("只有队长才能操作");
                }
                ensureTeamEditable(approverRegister, approverUserId, true);
            } else {
                ensureTeamEditable(teamInfo, approverUserId, false);
                String approverStudentNo = getStudentNoByUserId(approverUserId);
                if (StringUtils.isEmpty(approverStudentNo) || !studentNo.equals(approverStudentNo))
                {
                    throw new ServiceException("只有被邀请学生才能处理该邀请");
                }
            }
            List<Map<String, Object>> filtered = new ArrayList<>();
            boolean rejected = false;
            for (Map<String, Object> m : members) {
                String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                if (studentNo.equals(mNo)) {
                    m.put("status", "rejected");
                    m.put("decisionTime", new Date().getTime());
                    rejected = true;
                    filtered.add(m);
                    continue;
                }
                filtered.add(m);
            }
            if (!rejected) {
                throw new ServiceException("Pending member not found");
            }
            String newJson = mapper.writeValueAsString(filtered);
            competitionRegisterMapper.updateTeamMembersByTeamId(teamId, newJson);
            return true;
        } catch (Exception e) {
            throw new ServiceException("Rejection failed");
        }
    }

    @Override
    public List<Map<String, Object>> listUserInvitations(Long userId)
    {
        List<Map<String, Object>> result = new ArrayList<>();
        SysUser user = sysUserMapper.selectUserById(userId);
        if (user == null) {
            return result;
        }
        String myNo = user.getStudentNo() != null ? user.getStudentNo() : user.getUserName();

        List<CompetitionRegister> allTeams = competitionRegisterMapper.selectAllTeams();
        ObjectMapper mapper = new ObjectMapper();
        for (CompetitionRegister team : allTeams) {
            if (team.getTeamMembers() == null || team.getTeamMembers().isEmpty()) continue;
            try {
                List<Map<String, Object>> members = mapper.readValue(team.getTeamMembers(), new TypeReference<List<Map<String, Object>>>() {});
                boolean isApprovedMember = false;
                for (Map<String, Object> m : members) {
                    String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                    String status = String.valueOf(m.getOrDefault("status", "pending"));
                    if (myNo.equals(mNo) && "approved".equalsIgnoreCase(status)) {
                        isApprovedMember = true;
                        break;
                    }
                }
                for (Map<String, Object> m : members) {
                    String status = String.valueOf(m.getOrDefault("status", "pending"));
                    String type = String.valueOf(m.getOrDefault("type", "invite"));
                    String mNo = String.valueOf(m.getOrDefault("studentNo", ""));
                    
                    if ("invite".equalsIgnoreCase(type) && myNo.equals(mNo) && "pending".equalsIgnoreCase(status)) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("id", team.getTeamId() + "-" + mNo + "-invite");
                        item.put("teamId", team.getTeamId());
                        item.put("teamName", team.getTeamName());
                        item.put("competitionId", team.getCompetitionId());
                        item.put("type", "invite");
                        item.put("memberName", m.getOrDefault("name", ""));
                        item.put("memberStudentNo", mNo);
                        item.put("status", "pending");
                        // ... inviter name logic ...
                        Object invNameObj = m.get("inviterName");
                        String invName = invNameObj != null ? String.valueOf(invNameObj) : "";
                        if (invName == null || invName.trim().isEmpty()) {
                            Object inviterIdObj = m.get("inviterId");
                            try {
                                if (inviterIdObj != null) {
                                    Long inviterId = Long.valueOf(String.valueOf(inviterIdObj));
                                    SysUser invUser = sysUserMapper.selectUserById(inviterId);
                                    if (invUser != null) {
                                         // ...
                                        String candidate = invUser.getStudentName();
                                        if (candidate == null) candidate = invUser.getNickName();
                                        if (candidate == null) candidate = invUser.getUserName();
                                        invName = candidate;
                                    }
                                }
                            } catch (Exception ignore) {}
                        }
                        if (invName != null) item.put("inviterName", invName);

                        Competition comp = competitionMapper.selectCompetitionById(team.getCompetitionId());
                        if (comp != null) {
                            item.put("competitionName", comp.getCompetitionName());
                        }
                        result.add(item);
                    }
                    
                    if ("apply".equalsIgnoreCase(type) && isApprovedMember && "pending".equalsIgnoreCase(status)) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("id", team.getTeamId() + "-" + mNo + "-apply");
                        item.put("teamId", team.getTeamId());
                        item.put("teamName", team.getTeamName());
                        item.put("competitionId", team.getCompetitionId());
                        item.put("type", "apply");
                        
                        String applicantName = m.get("name") != null ? String.valueOf(m.get("name")) : "";
                        if (applicantName == null || applicantName.trim().isEmpty()) {
                            SysUser appUser = sysUserMapper.selectUserByStudentNo(mNo);
                            if (appUser == null) appUser = sysUserMapper.selectUserByUserName(mNo);
                            if (appUser != null) {
                                applicantName = appUser.getStudentName();
                                if (applicantName == null) applicantName = appUser.getNickName();
                                if (applicantName == null) applicantName = appUser.getUserName();
                            }
                        }
                        
                        item.put("memberName", applicantName != null ? applicantName : "Unknown member");
                        item.put("applicantName", applicantName != null ? applicantName : "Unknown member");
                        item.put("memberStudentNo", mNo);
                        item.put("status", "pending");
                        Competition comp = competitionMapper.selectCompetitionById(team.getCompetitionId());
                        if (comp != null) {
                            item.put("competitionName", comp.getCompetitionName());
                        }
                        result.add(item);
                    }

                    if ("apply".equalsIgnoreCase(type) && myNo.equals(mNo) && !"pending".equalsIgnoreCase(status)) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("id", team.getTeamId() + "-" + mNo + "-apply-result");
                        item.put("teamId", team.getTeamId());
                        item.put("teamName", team.getTeamName());
                        item.put("competitionId", team.getCompetitionId());
                        item.put("type", "apply-result");
                        item.put("memberName", m.getOrDefault("name", ""));
                        item.put("applicantName", m.getOrDefault("applicantName", m.getOrDefault("name", "")));
                        item.put("memberStudentNo", mNo);
                        item.put("status", status.toLowerCase());
                        item.put("read", false);
                        item.put("createTime", m.getOrDefault("decisionTime", m.getOrDefault("createTime", "")));
                        Competition comp = competitionMapper.selectCompetitionById(team.getCompetitionId());
                        if (comp != null) {
                            item.put("competitionName", comp.getCompetitionName());
                        }
                        result.add(item);
                    }
                }
            } catch (Exception ignore) {
            }
        }
        return result;
    }
    @Override
    public void recordLearning(Long competitionId) {
        Competition competition = competitionMapper.selectCompetitionById(competitionId);
        if (competition != null) {
            competition.setLearningCount((competition.getLearningCount() == null ? 0 : competition.getLearningCount()) + 1);
            competitionMapper.updateCompetition(competition);
        }
    }

    private void replaceTeacherTeams(Long teamId, List<Map<String, Object>> teacherList)
    {
        if (teamId == null)
        {
            return;
        }
        teacherTeamRelMapper.deleteByTeamId(teamId);
        List<TeacherTeamRel> rows = new ArrayList<>();
        Set<Long> teacherIds = new LinkedHashSet<>();
        if (teacherList != null)
        {
            for (Map<String, Object> teacher : teacherList)
            {
                if (teacher == null)
                {
                    continue;
                }
                Long teacherId = parseLongValue(teacher.get("teacherId"));
                if (teacherId == null || !teacherIds.add(teacherId))
                {
                    continue;
                }
                TeacherTeamRel row = new TeacherTeamRel();
                row.setTeamId(teamId);
                row.setTeacherId(teacherId);
                rows.add(row);
            }
        }
        if (!rows.isEmpty())
        {
            teacherTeamRelMapper.batchInsert(rows);
        }
    }

    private List<Map<String, Object>> buildTeacherResponse(Long teamId)
    {
        List<Map<String, Object>> result = new ArrayList<>();
        if (teamId == null)
        {
            return result;
        }
        List<TeacherTeamRel> relations = teacherTeamRelMapper.selectByTeamId(teamId);
        if (relations == null || relations.isEmpty())
        {
            return result;
        }
        List<Long> teacherIds = new ArrayList<>();
        for (TeacherTeamRel relation : relations)
        {
            if (relation.getTeacherId() != null)
            {
                teacherIds.add(relation.getTeacherId());
            }
        }
        if (teacherIds.isEmpty())
        {
            return result;
        }
        List<TeacherTeam> teachers = teacherTeamMapper.selectBaseTeachersByIds(teacherIds);
        Map<Long, TeacherTeam> teacherMap = new HashMap<>();
        for (TeacherTeam teacher : teachers)
        {
            teacherMap.put(teacher.getId(), teacher);
        }
        for (TeacherTeamRel relation : relations)
        {
            TeacherTeam teacher = teacherMap.get(relation.getTeacherId());
            if (teacher != null)
            {
                result.add(buildTeacherItem(teacher));
            }
        }
        return result;
    }

    private Map<String, Object> buildTeacherItem(TeacherTeam teacher)
    {
        Map<String, Object> item = new HashMap<>();
        item.put("teacherId", teacher.getId());
        item.put("name", teacher.getTeacherName() == null ? "" : teacher.getTeacherName());
        item.put("gender", resolveTeacherGender(teacher.getSex()));
        item.put("birthDate", teacher.getBirthDate() == null ? "" : teacher.getBirthDate());
        item.put("enrollYear", "");
        item.put("phone", teacher.getPhone() == null ? "" : teacher.getPhone());
        item.put("email", teacher.getEmail() == null ? "" : teacher.getEmail());
        item.put("unit", teacher.getWorkUnit() == null ? "" : teacher.getWorkUnit());
        item.put("title", teacher.getTitle() == null ? "" : teacher.getTitle());
        item.put("position", teacher.getPosition() == null ? "" : teacher.getPosition());
        item.put("politicalStatus", teacher.getPoliticalStatus() == null ? "" : teacher.getPoliticalStatus());
        return item;
    }

    private String resolveTeacherGender(String sex)
    {
        if ("0".equals(sex))
        {
            return "male";
        }
        if ("1".equals(sex))
        {
            return "female";
        }
        return "";
    }
    private void cleanupTeacherTeamsIfEmpty(Long teamId)
    {
        if (teamId == null)
        {
            return;
        }
        List<CompetitionRegister> teamRegs = competitionRegisterMapper.selectByTeamId(teamId);
        if (teamRegs == null || teamRegs.isEmpty())
        {
            teacherTeamRelMapper.deleteByTeamId(teamId);
        }
    }

    private Long parseLongValue(Object value)
    {
        if (value == null)
        {
            return null;
        }
        try
        {
            return Long.valueOf(String.valueOf(value));
        }
        catch (NumberFormatException e)
        {
            return null;
        }
    }
}
