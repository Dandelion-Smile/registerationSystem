import request from "@/utils/request";

// 学生端：获取竞赛列表（支持分页和筛选）
export function listStudentCompetitions(pageNum, pageSize, filters) {
  return request({
    url: "/student/competition/list",
    method: "get",
    params: {
      pageNum: pageNum || 1,
      pageSize: pageSize || 10,
      keyword: filters?.keyword || "",
      filterType: filters?.type || "",
      filterLevel: filters?.level || "",
      filterStatus: filters?.status || "",
      filterParticipants: filters?.participants || "",
    },
  });
}

// 学生端：查询当前用户在某个竞赛下的报名状态
export function getCompetitionTypes() {
  return request({
    url: "/student/competition/types",
    method: "get",
  });
}

export function getCompetitionStatus(competitionId) {
  return request({
    url: `/student/competition/${competitionId}/status`,
    method: "get",
  });
}

// 学生端：获取竞赛详情
export function getCompetitionDetail(competitionId) {
  return request({
    url: `/student/competition/${competitionId}`,
    method: "get",
  });
}

// 学生端：报名竞赛
export function registerCompetition(data) {
  return request({
    url: "/student/competition/register",
    method: "post",
    data: data,
  });
}

// 学生端：获取竞赛的队伍列表
export function saveCompetitionTeamName(data) {
  return request({
    url: "/student/competition/team/name",
    method: "post",
    data: data,
  });
}

export function getCompetitionTeams(competitionId) {
  return request({
    url: `/student/competition/${competitionId}/teams`,
    method: "get",
  });
}

// 学生端：查询已上传的参赛材料信息
export function getUploadedMaterials(registerId) {
  return request({
    url: `/student/competition/material/${registerId}`,
    method: "get",
  });
}

// 学生端：查询当前用户最近N条报名记录
export function getRecentRegistrations(limit = 10) {
  return request({
    url: "/student/competition/recent-registrations",
    method: "get",
    params: { limit },
  });
}

// 学生端：提交材料
export function submitMaterials(data) {
  return request({
    url: "/student/competition/material",
    method: "post",
    data: data,
  });
}

export function cancelRegistration(registerId) {
  return request({
    url: `/student/competition/register/${registerId}`,
    method: "delete",
  });
}

export function getTeamInvitations() {
  return request({
    url: "/student/competition/team/invitations",
    method: "get",
    headers: { silent: true },
    validateStatus: () => true,
  });
}

export function approveTeamInvitation(teamId, studentNo, userId) {
  return request({
    url: "/student/competition/team/approve",
    method: "post",
    data: { teamId, studentNo, userId },
    headers: { silent: true },
    validateStatus: () => true,
  });
}

export function rejectTeamInvitation(teamId, studentNo, userId) {
  return request({
    url: "/student/competition/team/reject",
    method: "post",
    data: { teamId, studentNo, userId },
    headers: { silent: true },
    validateStatus: () => true,
  });
}

export function inviteTeamMember(teamId, studentNo) {
  return request({
    url: "/student/competition/team/invite",
    method: "post",
    data: { teamId, studentNo },
  });
}

export function applyJoinTeam(teamId) {
  return request({
    url: "/student/competition/team/apply",
    method: "post",
    data: { teamId },
  });
}

export function removeTeamMember(teamId, studentNo) {
  return request({
    url: "/student/competition/team/remove",
    method: "post",
    data: { teamId, studentNo },
  });
}
