<template>
  <div class="min-h-screen bg-[#f9fafb] font-sans text-left pb-16">
    <nav class="h-16 bg-[#722ed1] flex items-center justify-between px-8 shadow-sm mb-8">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 bg-yellow-400 rounded-lg flex items-center justify-center shadow-inner">
          <i class="fa fa-trophy text-white text-sm"></i>
        </div>
        <div class="flex flex-col">
          <span class="text-white font-black tracking-widest text-lg leading-none mb-1">“智启赛途”</span>
          <span class="text-white/60 text-[10px] font-bold uppercase tracking-tighter">高校竞赛AI智驭平台</span>
        </div>
      </div>
      <el-dropdown trigger="click" placement="bottom-end" @command="handleUserCommand">
        <button class="user-menu-trigger">
          <div class="text-right hidden md:block">
            <p class="text-white text-xs font-black leading-none">系统管理员</p>
            <p class="text-white/50 text-[10px] font-mono">{{ userStore.name || 'admin' }}</p>
          </div>
          <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center border-2 border-white/20">
            <i class="fa fa-user-circle text-[#722ed1]"></i>
          </div>
          <i class="fa fa-chevron-down text-white/80 text-xs"></i>
        </button>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item command="profile">
              <i class="fa fa-user-circle-o mr-2"></i>
              <span>个人中心</span>
            </el-dropdown-item>
            <el-dropdown-item command="logout" divided>
              <i class="fa fa-sign-out mr-2"></i>
              <span>退出登录</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
      <div class="hidden">
        <div class="text-right hidden md:block">
          <p class="text-white text-xs font-black leading-none">系统管理员</p>
          <p class="text-white/50 text-[10px] font-mono">admin</p>
        </div>
        <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center border-2 border-white/20">
          <i class="fa fa-user-circle text-[#722ed1]"></i>
        </div>
      </div>
    </nav>

    <div class="max-w-7xl mx-auto px-6 grid grid-cols-12 gap-8">
      <div class="col-span-12 lg:col-span-9 space-y-8">

        <div class="bg-white rounded-[2.5rem] p-10 border border-gray-100 shadow-sm relative overflow-hidden">
          <div class="absolute top-0 right-0 w-40 h-40 bg-[#722ed1]/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>

          <div class="relative z-10 space-y-6">
            <div class="space-y-2">
              <div class="flex items-center gap-2">
                <span class="w-2 h-2 bg-[#722ed1] rounded-full"></span>
                <span class="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Detailed Archives</span>
              </div>
              <h1 class="text-4xl font-black text-gray-900 tracking-tight">{{ team.teamName || '加载中...' }}</h1>
            </div>

            <div class="flex flex-wrap gap-3">
              <div class="px-4 py-2 bg-purple-50 rounded-xl flex items-center gap-2 border border-purple-100">
                <i class="fa fa-user-circle text-[#722ed1] text-xs"></i>
                <span class="text-xs font-bold text-gray-600">负责人: <span class="text-[#722ed1]">{{ getLeader(team.teamMembers) }}</span></span>
              </div>
              <div class="px-4 py-2 bg-green-50 rounded-xl flex items-center gap-2 border border-green-100">
                <i class="fa fa-users text-green-500 text-xs"></i>
                <span class="text-xs font-bold text-gray-600">成员: <span class="text-green-600">{{ parseMembers(team.teamMembers).length }} 人</span></span>
              </div>
              <div class="px-4 py-2 bg-yellow-50 rounded-xl flex items-center gap-2 border border-yellow-100">
                <i class="fa fa-book text-yellow-600 text-xs"></i>
                <span class="text-xs font-bold text-gray-600">作品: <span class="text-yellow-700">《{{ team.workName || '无' }}》</span></span>
              </div>
              <div class="px-4 py-2 bg-orange-50 rounded-xl flex items-center gap-2 border border-orange-100">
                <i class="fa fa-star text-orange-500 text-xs"></i>
                <span class="text-xs font-bold text-gray-600">综合平均分: <span class="text-orange-600">{{ team.avgScore || '0.00' }}</span></span>
              </div>
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          <section class="bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm space-y-8">
            <div class="flex items-center gap-3">
              <div class="w-1.5 h-6 bg-[#722ed1] rounded-full"></div>
              <h3 class="text-lg font-black text-gray-800">基本信息</h3>
            </div>
            <div class="space-y-4 px-2">
              <div v-for="(val, label) in { '队伍名称': team.teamName, '指导老师': team.teacherName || '未指定', '负责人': getLeader(team.teamMembers), '成员数量': parseMembers(team.teamMembers).length + ' 人' }" :key="label"
                   class="flex justify-between items-center py-3 border-b border-gray-50 last:border-0">
                <span class="text-sm font-bold text-gray-400">{{ label }}</span>
                <span class="text-sm font-black text-gray-700">{{ val }}</span>
              </div>
            </div>
          </section>

          <section class="bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm space-y-6">
            <div class="flex items-center gap-3">
              <div class="w-1.5 h-6 bg-green-500 rounded-full"></div>
              <h3 class="text-lg font-black text-gray-800">作品信息</h3>
            </div>
            <div class="px-2 space-y-4">
              <div>
                <span class="text-[10px] font-black text-gray-300 uppercase block mb-1">作品名称</span>
                <p class="text-sm font-black text-gray-700">{{ team.workName || '无' }}</p>
              </div>
              <div class="bg-gray-50 p-6 rounded-2xl">
                <span class="text-[10px] font-black text-gray-300 uppercase block mb-2">作品简介</span>
                <p class="text-sm text-gray-500 leading-relaxed italic">
                  {{ team.workDescription || '无' }}
                </p>
              </div>
            </div>
          </section>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <section class="md:col-span-1 bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm space-y-6">
            <div class="flex items-center gap-3">
              <div class="w-1.5 h-6 bg-yellow-500 rounded-full"></div>
              <h3 class="text-lg font-black text-gray-800">成员列表</h3>
            </div>
            <div class="flex flex-col gap-3">
              <div v-for="(m, i) in parseMembers(team.teamMembers)" :key="i"
                   class="px-5 py-3 bg-white border border-gray-50 rounded-2xl flex items-center justify-between shadow-sm">
                <span class="text-sm font-black text-gray-700">{{ m.name || m }}</span>
                <i class="fa fa-check-circle text-green-400 text-xs"></i>
              </div>
            </div>
          </section>

          <section class="md:col-span-2 bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm space-y-6">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-1.5 h-6 bg-purple-500 rounded-full"></div>
                <h3 class="text-lg font-black text-gray-800">评分信息</h3>
              </div>
              <div class="px-4 py-1.5 bg-purple-50 text-[#722ed1] text-[10px] font-black rounded-lg uppercase tracking-widest">
                Latest Score
              </div>
            </div>
            <div class="grid grid-cols-2 gap-6">
              <div class="p-6 bg-[#fcfaff] rounded-3xl border border-purple-50 text-center">
                <p class="text-[10px] font-black text-gray-400 uppercase mb-2">平均分数</p>
                <p class="text-4xl font-mono font-black text-[#722ed1]">{{ team.avgScore ? parseFloat(team.avgScore).toFixed(2) : '0.00' }}</p>
              </div>
              <div class="p-6 bg-[#fcfaff] rounded-3xl border border-purple-50 text-center">
                <p class="text-[10px] font-black text-gray-400 uppercase mb-2">评审轮次</p>
                <p class="text-4xl font-mono font-black text-gray-700">{{ teamScores.length }}</p>
              </div>
            </div>
          </section>
        </div>

        <section class="bg-white rounded-[2.5rem] p-10 border border-gray-100 shadow-sm">
          <div class="flex items-center gap-3 mb-10">
            <div class="w-1.5 h-8 bg-orange-500 rounded-full"></div>
            <h2 class="text-2xl font-black text-gray-800">教师评分详情</h2>
          </div>
          <div class="overflow-hidden rounded-3xl border border-gray-50">
            <table class="w-full text-left">
              <thead class="bg-gray-50/50">
              <tr>
                <th class="px-8 py-5 text-[10px] font-black text-gray-400 uppercase">教师名称</th>
                <th class="px-8 py-5 text-[10px] font-black text-gray-400 uppercase text-center">评分</th>
                <th class="px-8 py-5 text-[10px] font-black text-gray-400 uppercase">评审建议</th>
              </tr>
              </thead>
              <tbody class="divide-y divide-gray-50">
              <tr v-for="(s, i) in teamScores" :key="i" class="hover:bg-gray-50/20 transition-all">
                <td class="px-8 py-6">
                  <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-[10px] font-black text-[#722ed1]">{{ s.reviewer_name?.charAt(0) }}</div>
                    <span class="font-black text-gray-700">{{ s.reviewer_name }}</span>
                  </div>
                </td>
                <td class="px-8 py-6 text-center">
                    <span class="px-4 py-1.5 bg-yellow-50 text-yellow-700 rounded-xl font-black text-sm border border-yellow-100">
                      {{ s.score }} 分
                    </span>
                </td>
                <td class="px-8 py-6 text-gray-500 italic text-sm">"{{ s.comment || '教师未留下详细评语' }}"</td>
              </tr>
              </tbody>
            </table>
            <div v-if="teamScores.length === 0" class="py-20 text-center text-gray-300 italic">目前暂无评审档案数据记录</div>
          </div>
        </section>
      </div>

      <div class="col-span-12 lg:col-span-3">
        <div class="sticky top-8 space-y-6">
          <div class="bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm space-y-10">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center">
                <i class="fa fa-bolt text-[#722ed1]"></i>
              </div>
              <h3 class="font-black text-gray-800">快速操作</h3>
            </div>
            <div class="space-y-4">
              <button @click="router.back()" class="w-full flex items-center justify-center gap-3 py-4 bg-white hover:bg-gray-50 text-gray-800 border-2 border-gray-900 rounded-2xl font-bold transition-all shadow-sm group">
                <i class="fa fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> 返回列表
              </button>
              <button @click="handleExport" class="w-full flex items-center justify-center gap-3 py-4 bg-[#722ed1] hover:bg-[#5c23b3] text-white rounded-2xl font-bold shadow-lg shadow-purple-100 transition-all active:scale-95">
                <i class="fa fa-cloud-download"></i> 导出数据
              </button>
            </div>
            <div class="pt-6 border-t border-gray-50 text-center">
              <p class="text-[10px] text-gray-300 font-mono tracking-tighter uppercase">Team ID: {{ team.registerId || 'N/A' }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import request from '@/utils/request'
import { ElMessageBox } from 'element-plus'
import useUserStore from '@/store/modules/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const team = ref({
  teamName: '',
  teamMembers: '[]',
  workName: '',
  workDescription: '',
  avgScore: 0,
  registerId: '',
  registerTime: ''
})
const teamScores = ref([])

const parseMembers = (s) => {
  if (!s) return []
  try { return typeof s === 'string' ? JSON.parse(s) : s } catch (e) { return [] }
}

const getLeader = (s) => {
  if (!s) return '加载中...'
  const m = parseMembers(s)
  if (m && Array.isArray(m) && m.length > 0) return (m[0].name || m[0])
  return '未知'
}

const fetchDetail = async () => {
  const { registerId } = route.params
  if (!registerId) return
  try {
    const teamRes = await request.get(`/admin/competition/team-detail/${registerId}`)
    if (teamRes && teamRes.data) team.value = teamRes.data
    const scoreRes = await request.get(`/admin/competition/team-scores/${registerId}`)
    if (scoreRes && scoreRes.data) teamScores.value = scoreRes.data
  } catch (error) {
    console.error("加载详情失败:", error)
  }
}

const handleExport = () => {
  // 导出逻辑执行
  console.log("执行导出...")
}

const handleUserCommand = (command) => {
  if (command === 'profile') {
    router.push('/sys-admin/profile')
    return
  }
  if (command === 'logout') {
    ElMessageBox.confirm('确定注销并退出系统吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      userStore.logOut().then(() => {
        location.href = '/index'
      })
    }).catch(() => {})
  }
}

onMounted(() => fetchDetail())
</script>

<style scoped>
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
* { -webkit-font-smoothing: antialiased; }
.text-left { text-align: left !important; }
.user-menu-trigger {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.375rem 1rem;
  border-radius: 0.75rem;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.1);
  cursor: pointer;
}
.user-menu-trigger:hover {
  background: rgba(255, 255, 255, 0.18);
}
</style>
