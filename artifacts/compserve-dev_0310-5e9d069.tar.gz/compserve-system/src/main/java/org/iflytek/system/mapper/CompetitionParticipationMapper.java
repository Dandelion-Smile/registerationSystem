package org.iflytek.system.mapper;

import org.iflytek.system.domain.CompetitionParticipation;

/**
 * 参赛材料 Mapper
 */
public interface CompetitionParticipationMapper
{
    int insertCompetitionParticipation(CompetitionParticipation participation);

    int updateCompetitionParticipation(CompetitionParticipation participation);

    CompetitionParticipation selectById(Long participationId);

    int deleteById(Long participationId);
}

